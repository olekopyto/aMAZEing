# Warsztat 1 — instrukcja uruchomienia

Wymagany Python 3.11 lub nowszy. Uruchom terminal w tym folderze.

```bash
python -m venv .venv
```
Windows PowerShell: `.venv\Scripts\Activate.ps1`

macOS/Linux: `source .venv/bin/activate`

```bash
python -m pip install -r requirements.txt
python -m notebook
```
Otwórz `warsztat1.ipynb` i uzupełniaj TODO po kolei.

