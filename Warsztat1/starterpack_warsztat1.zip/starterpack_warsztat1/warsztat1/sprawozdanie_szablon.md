# Warsztat 1 — Dobór ekwipunku bohatera

## 1. Temat i autorzy

**Temat:** Dobór ekwipunku bohatera — porównanie losowania i symulowanego wyżarzania w problemie plecakowym 0/1  
**Data:** 28.10.2026  
**Numer/nazwa zespołu:** _[uzupełnijcie]_  
**Członkowie zespołu (imiona i nazwiska):** _[uzupełnijcie]_  
**Przewodnik z zespołu liderskiego (imię i nazwisko):** _[uzupełnijcie]_

## 2. Cel i wykonane zmiany

**Cel:** Wybrać spośród 12 przedmiotów ekwipunek o maksymalnej sumie wartości, którego łączna masa nie przekracza 15 kg. Porównać metodę losową i symulowane wyżarzanie z optimum wyznaczonym przez pełny przegląd 4096 kombinacji.

**Reprezentacja rozwiązania:** wektor 12 zer i jedynek (1 — przedmiot wybrany, 0 — pominięty).

**Uzupełnione lub zmienione elementy notatnika:**
- _[uzupełnijcie]_

**Ręczna weryfikacja dwóch przykładowych zestawów (pierwsze 10 minut):**

| Zestaw / wybrane przedmioty | Suma mas [kg] | Suma wartości | Czy dopuszczalny (≤ 15 kg)? |
|---|---:|---:|---|
| Przykład 1: _[uzupełnijcie]_ | — | — | — |
| Przykład 2: _[uzupełnijcie]_ | — | — | — |

## 3. Eksperyment

**Dane:** `data/items.csv` — 12 przedmiotów, każdy z masą i dodatnią wartością użytkową.  
**Pojemność plecaka:** 15 kg.  
**Porównywane metody:** losowanie (`random_search`) i symulowane wyżarzanie (`simulated_annealing`).  
**Punkt odniesienia:** pełny przegląd (`brute_force`), **poza** budżetem porównywanych metod.

| Parametr | Użyta wartość |
|---|---|
| Liczba prób na jedno uruchomienie każdej metody | _[domyślnie 500]_ |
| Ziarna losowości (`seed`) | _[domyślnie 0, 1, 2, 3, 4]_ |
| Temperatura początkowa (`T0`) | _[domyślnie 8.0]_ |
| Współczynnik chłodzenia (`alpha`) | _[domyślnie 0.998]_ |
| Inne zmiany parametrów (jeśli były) | _[brak / opiszcie]_ |

**Zasady liczenia prób:** przeciążone propozycje są odrzucane, ale nadal liczą się do budżetu. W wyżarzaniu sąsiad powstaje przez zmianę jednego bitu; gorszy, dopuszczalny zestaw może zostać przyjęty z prawdopodobieństwem `exp(-spadek / T)`. Temperatura jest obniżana po każdej próbie, również odrzuconej.

**Jak przeprowadziliśmy test:** _[uzupełnijcie]_

### 3.1. Opcjonalne rozszerzenie
 _[uzupełnijcie lub usuńcie podsekcję]_

## 4. Wyniki

### 4.1. Wynik optymalny i przykładowe ekwipunki

**Optimum (pełny przegląd):** _[wartość]_ pkt, **masa:** _[masa]_ kg.  
**Najlepszy zestaw znaleziony przez metodę losową:** _[nazwy przedmiotów lub wektor 0/1; wartość i masa]_.  
**Najlepszy zestaw znaleziony przez wyżarzanie:** _[nazwy przedmiotów lub wektor 0/1; wartość i masa]_.

### 4.2. Porównanie dla pięciu ziaren

> **Strata względem optimum** = wartość optimum − uzyskana wartość. Wpiszcie wyniki z własnych uruchomień, także te gorsze od oczekiwanych.

| Seed | Losowanie: wartość | Losowanie: masa [kg] | Losowanie: strata | Wyżarzanie: wartość | Wyżarzanie: masa [kg] | Wyżarzanie: strata |
|---:|---:|---:|---:|---:|---:|---:|
| 0 | — | — | — | — | — | — |
| 1 | — | — | — | — | — | — |
| 2 | — | — | — | — | — | — |
| 3 | — | — | — | — | — | — |
| 4 | — | — | — | — | — | — |
| **Średnia** | — | — | — | — | — | — |

**Liczba trafień w optimum:** losowanie _[...]/5_, wyżarzanie _[...]/5_.

### 4.3. Wykres i obserwacje

**Wykres:** _[uzupełnijcie]_.

**Najlepsza a aktualna wartość:** _[uzupełnijcie]_.

**Nieudane lub odrzucone próby / problemy:** _[uzupełnijcie]_.

**Przykładowa decyzja wyżarzania:** _[uzupełnijcie]_.

## 5. Wnioski i ograniczenia

**Wnioski z porównania:** _[uzupełnijcie]_.

**Dlaczego wyżarzanie może zaakceptować gorszy zestaw?** _[uzupełnijcie]_.

**Ograniczenia eksperymentu:** _[uzupełnijcie]_.

**Stan rozwiązania na koniec 90 minut:** _[uzupełnijcie]_.

**Wkład członków zespołu:**

| Imię i nazwisko | Wykonane zadania podczas warsztatu |
|---|---|
| _[osoba 1]_ | _[uzupełnijcie]_ |
| _[osoba 2]_ | _[uzupełnijcie]_ |
| _[osoba 3]_ | _[uzupełnijcie]_ |
| _[osoba 4, jeśli dotyczy]_ | _[uzupełnijcie]_ |
| _[osoba 5, jeśli dotyczy]_ | _[uzupełnijcie]_ |
