"""Narzędzia pomocnicze do doboru ekwipunku. Masy w kg, wartości w punktach."""

import csv
from dataclasses import dataclass
from itertools import product
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.axes import Axes


CAPACITY = 15.0  # domyślna pojemność plecaka w kilogramach


@dataclass(frozen=True)
class Problem:
    """Dane zadania; kolejność przedmiotów zgodna z CSV."""

    names: list[str]       # nazwy n przedmiotów
    masses: np.ndarray    # float, kształt (n,), masy w kg
    values: np.ndarray    # int, kształt (n,), wartości w punktach
    capacity: float       # limit masy w kg


@dataclass
class Result:
    """Wynik jednego uruchomienia metody."""

    best_x: np.ndarray           # kształt (n,), zera i jedynki, dtype=np.int8
    best_value: float           # wartość najlepszego zestawu
    best_mass: float            # masa najlepszego zestawu w kg
    history_best: np.ndarray     # najlepsza wartość po każdej próbie; nigdy nie maleje
    history_current: np.ndarray  # aktualna wartość po każdej próbie


def load_problem(
    path: str | Path = "data/items.csv", capacity: float = CAPACITY
) -> Problem:
    """Przyjmuje ścieżkę CSV i limit masy w kg. Zwraca Problem.

    W Colabie: uruchom !mkdir -p /content/data, a następnie w panelu
    plików wgraj items.csv do folderu data. load_problem() wczyta ten plik,
    jeśli bieżącym katalogiem jest /content (domyślnie w Colabie).
    """
    with open(path, encoding="utf-8", newline="") as file:
        rows = list(csv.DictReader(file))

    return Problem(
        names=[row["name"] for row in rows],
        masses=np.array([float(row["mass"]) for row in rows], dtype=float),
        values=np.array([int(row["value"]) for row in rows], dtype=int),
        capacity=float(capacity),
    )


def evaluate(x: np.ndarray, problem: Problem) -> tuple[float, float, bool]:
    """Przyjmuje wektor 0/1 i Problem. Zwraca (wartość, masa w kg, czy mieści się)."""
    value = float(np.dot(x, problem.values))
    # Zaokrąglamy przed sprawdzeniem limitu, aby uniknąć błędów typu 15.000000000000002.
    mass = round(float(np.dot(x, problem.masses)), 1)
    return value, mass, mass <= problem.capacity


def brute_force(problem: Problem) -> Result:
    """Przyjmuje Problem. Sprawdza wszystkie zestawy i zwraca optimum; historie puste."""
    item_count = len(problem.names)

    # Początkowo najlepszym zestawem jest pusty plecak.
    best_x = np.zeros(item_count, dtype=np.int8)
    best_value = 0.0
    best_mass = 0.0

    # Każdy przedmiot można zostawić (0) lub zabrać (1).
    all_combinations = product((0, 1), repeat=item_count)

    for combination in all_combinations:
        selection = np.array(combination, dtype=np.int8)
        value, mass, feasible = evaluate(selection, problem)

        # Zapamiętujemy tylko lepszy zestaw mieszczący się w plecaku.
        if feasible and value > best_value:
            best_x = selection
            best_value = value
            best_mass = mass

    return Result(
        best_x=best_x,
        best_value=best_value,
        best_mass=best_mass,
        history_best=np.array([]),
        history_current=np.array([]),
    )


def show_knapsack(x: np.ndarray, problem: Problem) -> None:
    """Przyjmuje wektor 0/1 i Problem. Wypisuje przedmioty i sumy; nic nie zwraca."""
    print(f"{'Przedmiot':<20} {'Masa [kg]':>10} {'Wartość':>10}")
    print("-" * 42)

    for index, selected in enumerate(x):
        if selected == 1:
            print(
                f"{problem.names[index]:<20} "
                f"{problem.masses[index]:>10.1f} "
                f"{problem.values[index]:>10d}"
            )

    if not np.any(x):
        print("Plecak jest pusty.")

    value, mass, feasible = evaluate(x, problem)
    print("-" * 42)
    print(f"{'Razem':<20} {mass:>10.1f} {value:>10.0f}")
    print(f"Limit masy: {problem.capacity:.1f} kg")
    print("Mieści się w plecaku: " + ("tak" if feasible else "nie"))


def plot_history(
    results: dict[str, Result], optimum: float, ax: Axes | None = None
) -> Axes:
    """Przyjmuje nazwane wyniki, wartość optimum i opcjonalne osie. Zwraca osie wykresu."""
    if ax is None:
        _, ax = plt.subplots(figsize=(8, 5))

    for method_name, result in results.items():
        attempts = np.arange(1, len(result.history_best) + 1)
        ax.plot(attempts, result.history_best, label=method_name)

    ax.axhline(optimum, color="black", linestyle="--", label=f"Optimum: {optimum:g}")
    ax.set_xlabel("Liczba prób")
    ax.set_ylabel("Najlepsza znaleziona wartość")
    ax.set_title("Postęp szukania ekwipunku")
    ax.grid(True, alpha=0.3)
    ax.legend()
    return ax
